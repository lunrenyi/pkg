pkg:info "traceroute"
x traceroute -v