pkg:info "nact"
x ncat -v