pkg:info "nmap"
x namp -v