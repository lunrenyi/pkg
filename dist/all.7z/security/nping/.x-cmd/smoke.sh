pkg:info "nping"
x nping -v