pkg:info "bandwhich"
x bandwich -v