pkg:info "openssl"
x openssl -v