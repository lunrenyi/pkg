# shellcheck shell=sh disable=SC2039,SC1090,SC3043,SC2263,SC2154,SC2115
___x_cmd_openssl_deactivate(){
    rm -rf "$___X_CMD_PKG_BIN_PATH/$name"
}
___x_cmd_openssl_deactivate