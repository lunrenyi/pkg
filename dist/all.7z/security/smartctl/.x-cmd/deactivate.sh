___x_cmd_smartctl_deactivate(){
    rm -rf "$___X_CMD_PKG_BIN_PATH/$name"
}
___x_cmd_smartctl_deactivate