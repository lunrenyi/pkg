pkg:info "deno"
deno -V