pkg:info "scala"
scalac -v