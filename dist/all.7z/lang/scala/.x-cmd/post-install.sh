___x_cmd_env_scala_copy_to_unpackdir(){
    chmod -R +x "$unpack_dir"/*/bin/*
}

___x_cmd_env_scala_copy_to_unpackdir