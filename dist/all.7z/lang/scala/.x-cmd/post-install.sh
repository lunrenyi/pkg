___x_cmd_scala_unpack(){
    ___x_cmd_pkg_install___unzip "$name" "$version" "$osarch"
}

___x_cmd_scala_unpack