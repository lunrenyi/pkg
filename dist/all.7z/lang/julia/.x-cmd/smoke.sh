jpkg:info "julia"
julia -v