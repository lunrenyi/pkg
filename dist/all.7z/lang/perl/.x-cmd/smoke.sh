pkg:info "perl"
perl -v