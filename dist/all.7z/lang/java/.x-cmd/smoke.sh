pkg:info "java"
javac -version