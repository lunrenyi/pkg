___x_cmd_node_activate(){
    if [ -d "$___X_CMD_PKG_INSTALL_PATH/$name/$version/bin" ]; then
        ___x_cmd_path_unshift "$___X_CMD_PKG_INSTALL_PATH/$name/$version/bin"
    else
        pkg:error "$___X_CMD_PKG_INSTALL_PATH/$name/$version/bin isn't exist. Activate $name $version failed" && return
    fi

    if  [ -n "$___X_CMD_PKG_INSTALL_PATH" ]; then
        export NPM_CONFIG_PREFIX="$___X_CMD_PKG_INSTALL_PATH/$name/$version/.npm"
        x path unshift "$___X_CMD_PKG_INSTALL_PATH/$name/$version/.npm/bin"
    fi
}
___x_cmd_node_activate