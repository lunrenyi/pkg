pkg:info "node"
node --version