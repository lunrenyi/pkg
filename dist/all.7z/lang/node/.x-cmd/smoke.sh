pkg:info "node"
x assert stdout '$___X_CMD_PKG_INSTALL_PATH/$name/$version/bin/node --version' <<A
v18.4.0
A


