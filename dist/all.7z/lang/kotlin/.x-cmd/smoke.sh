pkg:info "kotlic"
kotlinc -version