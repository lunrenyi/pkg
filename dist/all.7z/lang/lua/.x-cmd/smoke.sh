pkg:info "lua"
x lua -v