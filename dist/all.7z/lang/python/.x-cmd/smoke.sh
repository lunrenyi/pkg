 pkg:info "python"
 pip -V