___x_cmd_python_deactivate(){
    x path rm "$___X_CMD_PKG_INSTALL_PATH/$pkg_name/$version/bin"
}

___x_cmd_python_deactivate
