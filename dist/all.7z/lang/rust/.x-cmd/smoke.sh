pkg:info "rust"
rustc -V