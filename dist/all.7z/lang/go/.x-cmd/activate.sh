___x_cmd_go_activate(){
    x path add_existed_folder "$___X_CMD_PKG_INSTALL_PATH/$pkg_name/$version/bin"
}

___x_cmd_go_activate