___x_cmd_go_unpack(){
    ___x_cmd_pkg_install___unzip "$pkg_name" "$version" "$osarch"
}

___x_cmd_go_unpack