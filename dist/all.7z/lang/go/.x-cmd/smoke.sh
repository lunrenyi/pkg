pkg:info "go"
gofmt -h