pkg:info "tig"
x tig -v