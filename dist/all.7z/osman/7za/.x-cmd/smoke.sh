pkg:info "7za"
x 7za -v