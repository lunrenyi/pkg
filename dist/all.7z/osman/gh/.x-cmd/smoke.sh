pkg:info "gh"
x gh