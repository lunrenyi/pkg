pkg:info "gh"
x gh -v