pkg:info "mosquitto"
mosquitto_test(){

    x assert 'eval '
}

mosquitto_test