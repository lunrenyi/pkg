pkg:info "mosquitto"
x mosquitto