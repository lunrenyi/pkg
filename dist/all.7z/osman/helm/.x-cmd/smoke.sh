pkg:info "helm"
x helm -v