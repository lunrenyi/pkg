pkg:info "exa"
x exa