pkg:info "exa"
x exa -v