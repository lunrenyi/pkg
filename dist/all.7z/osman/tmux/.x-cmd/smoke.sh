pkg:info "tmux"
x tmux -v