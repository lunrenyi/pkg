pkg:info "ucloud"
x ulcoud -v