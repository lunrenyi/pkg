pkg:info "jq"
x jq