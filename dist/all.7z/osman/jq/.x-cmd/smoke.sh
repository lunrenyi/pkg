pkg:info "jq"
x jq -v