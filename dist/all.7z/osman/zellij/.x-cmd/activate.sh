# shellcheck shell=sh disable=SC2154,SC1090,SC3043
___x_cmd_zellij_premise_activate(){
    export SHELL="$___X_CMD_CUR_SHELL"
}
___x_cmd_zellij_premise_activate