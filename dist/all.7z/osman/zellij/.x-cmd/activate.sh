# shellcheck shell=sh disable=SC2154,SC1090,SC3043
___x_cmd_zsh_plugin_activate(){
    export SHELL=$0
}
___x_cmd_zsh_plugin_activate