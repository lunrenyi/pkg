pkg:info "zellij"
x zellij -v