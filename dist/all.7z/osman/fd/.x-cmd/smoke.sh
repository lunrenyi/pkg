pkg:info "fd"
x fd