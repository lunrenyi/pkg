pkg:info "fd"
x fd -v