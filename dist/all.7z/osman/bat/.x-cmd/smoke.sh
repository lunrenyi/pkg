pkg:info "bat"
x bat ./lib/latest