pkg:info "bat"
x bat -v