pkg:info "procs"
x procs