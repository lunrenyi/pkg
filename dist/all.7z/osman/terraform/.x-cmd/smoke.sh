pkg:info "terraform"
x terraform -v