# shellcheck shell=sh disable=SC2154,SC2115
___x_cmd_proot_deactivate(){
    rm -rf "$___X_CMD_PKG_BIN_PATH/$name"
}
___x_cmd_proot_deactivate