pkg:info "rg"
x rg -v