pkg:info "curl"
x curl -v