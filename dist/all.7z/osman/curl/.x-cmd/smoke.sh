pkg:info "curl"
x curl