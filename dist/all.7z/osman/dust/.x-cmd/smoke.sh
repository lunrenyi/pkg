pkg:info "dust"
x dust