pkg:info "dust"
x dust -v