pkg:info "qrencode"
x qrencode -v