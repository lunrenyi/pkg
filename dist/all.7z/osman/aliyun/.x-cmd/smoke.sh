pkg:info "aliyun"
x aliyun -v