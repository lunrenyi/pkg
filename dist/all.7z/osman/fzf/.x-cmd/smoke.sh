pkg:info "fzf"
x fzf -v