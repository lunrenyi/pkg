pkg:info "fzf"
x fzf