pkg:info "yq"
x yq -v