# shellcheck shell=sh disable=
___x_cmd_zsh_plugin_activate(){
    echo 1111
}
___x_cmd_zsh_plugin_activate