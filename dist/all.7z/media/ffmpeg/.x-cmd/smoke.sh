pkg:info "ffmpeg"
x ffmpeg