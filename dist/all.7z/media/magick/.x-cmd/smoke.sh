pkg:info "magick"
x magick