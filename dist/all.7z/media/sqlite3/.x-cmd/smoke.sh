pkg:info "sqlite3"
x sqlite3